import {createContext} from 'react'

export const ListItemContext=createContext();

export const ListItemProvider=({children})=>{
     return <ListItemContext.Provider value='Abc'>
        {children}
     </ListItemContext.Provider>
}