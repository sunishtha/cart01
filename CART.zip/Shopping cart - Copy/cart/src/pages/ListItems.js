import React, { useState, useEffect } from 'react';
import axios from 'axios'
import { Grid, Image, Text, GridItem, Button,  Box, Spacer } from '@chakra-ui/react'
import { AiOutlineHeart } from 'react-icons/ai';
import {useNavigate,Link} from 'react-router-dom'
import Nav from '../components/Nav/Nav';


export default function ListItems() {
  


  const wishlistPage=useNavigate();
  const [list, setList] = useState([]);
  

  async function getProduct() {
   const res=await axios.get('https://641d9d2a945125fff3d19460.mockapi.io/api/cart-api')
   const products=await res.data;
  setList(res.data);
  
  }
  useEffect(() => {
    getProduct();

  }, [])

  const addToWishList=(listItem)=>{ 
   
    wishlistPage('/products/:id')
  }

  return (
      <>
      <Nav/>
      <Text fontSize={'3xl'} p={1} color={'pink.400'}>
       EXPLORE US!!
      </Text>
      
    <Grid templateColumns='repeat(3, 1fr)' gap={9}>
      
      {
        list.map((listItem, id) => {
          return (
          
            <GridItem p={9} key={listItem.id} 
            
            bgColor={'rgba(77, 222, 248, 0.185)'}  >
              <Link to={`products${listItem.id}`}>
              <Image src={listItem.img} />
              <Text fontSize='2xl'>{listItem.title}</Text>
              <Text fontSize='md'>{listItem.description}</Text>
              <Text color={'blue'} fontSize='xl'>{listItem.price}</Text>
              <Box p={5}
               display={'flex'} alignItems={'center'}
               justifyContent={'center'}
              >
                <Button 
                colorScheme='pink' variant='outline' >Add To Cart</Button>
                <Spacer/> 
                <AiOutlineHeart 
                onClick={()=>addToWishList(listItem)}
                 color='pink' size={33}  />
              </Box>
              </Link>
            </GridItem>
          )

        })
      }
     <br/><br/>
    </Grid>

</>
  )
}