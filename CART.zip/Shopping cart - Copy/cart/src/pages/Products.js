import React from 'react';
import { ListItemProvider } from '../context/ListItemContext';
import ListItems from './ListItems';


export default function Products() {
  

  return(
    <ListItemProvider>
  <ListItems/>
     </ListItemProvider>
   
   
  )
}